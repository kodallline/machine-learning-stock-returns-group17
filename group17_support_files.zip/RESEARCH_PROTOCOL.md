# Research protocol: retention buffers and net ML portfolio returns

## Connection to the paper

Avramov, Cheng and Metzker (2023), *Machine Learning vs. Economic Restrictions: Evidence from Stock Return Predictability*, Management Science 69(5), 2587–2619. DOI: https://doi.org/10.1287/mnsc.2022.4449

The article questions whether apparent ML portfolio profitability survives economic restrictions, including trading costs. Our adaptation isolates one implementability mechanism: whether a retention buffer can reduce unnecessary turnover and improve returns after transaction costs.

## Hypothesis and scope

H1: holding-buffer portfolios have lower traded notional than monthly top-decile replacement portfolios using identical return forecasts.

H2: at positive scenario trading costs, the buffer can improve average net return or net Sharpe ratio, despite potentially reducing gross return. This is a hypothesis, not an established result.

This is a controlled empirical extension for a course project, not a claim to invent retention buffers or a full replication of the article. A positive outcome is not guaranteed. The criteria for the highest course grade must be confirmed with the instructor.

## Frozen data choices

- Source: Yahoo Finance daily chart responses, stored as an auditable snapshot with request URLs and SHA-256 hashes.
- Price field: adjusted close, used to approximate split/dividend-adjusted returns. Source explanation: https://help.yahoo.com/kb/SLN28256.html . Historical series may be revised by the provider.
- Universe: 50 named U.S.-listed stocks in USD, manually selected before model fitting in this project. This is a convenience sample of surviving firms, not contemporaneous index membership and not a sample selected by historical portfolio returns.
- Raw request window: 2003-01-01 inclusive to 2026-02-01 exclusive.
- Holding months: January 2005 to December 2025. Earlier data provide lookbacks; January 2026 is used only to close the final holding interval.
- Features: 16 scale-free trailing return, volatility, trend, drawdown and relative-volume measures.
- No market cap, ratings, fundamentals or macroeconomic interactions are fabricated.
- Exact source snapshot and split definitions are shared by all participants.

## Timing

For the monthly signal date s, calculate X using prices and volumes through close s. Trade at the next month's first trading close e. Evaluate the holding interval to the following month's first trading close x:

`target_return = adjusted_close(x) / adjusted_close(e) - 1`.

Thus `s < e < x`. This gives time to compute the forecast; it avoids claiming execution at the close just used to construct features. It assumes close execution plus a scenario cost, not measured achievable fills. Do not add cash dividends a second time to adjusted-price returns.

## Evaluation design for subsequent participants

- Compare Ridge and NN3 forecasts. For each forecast model, keep predictions identical between baseline and buffer portfolios.
- Long-only, equal-weighted, fixed 5-position portfolios. No leverage or short selling.
- Baseline: replace holdings with the 5 highest-ranked forecasts each month.
- Buffer candidate exit thresholds: rank 8, 10 or 15, chosen using validation results only. State the slot-filling rule; see MODEL_HANDOFF.md.
- One-way cost scenarios: 0, 10, 25 and 50 basis points per traded dollar. They are assumptions, not measured market costs.
- Choose the buffer on validation using a predeclared primary criterion, for example net Sharpe at 25 bps, then freeze it for test.
- Report gross/net return, annualized volatility, Sharpe with a stated risk-free convention, maximum drawdown, and traded-notional turnover.
- Use the same-universe equal-weighted strategy as a simple benchmark.
- Evaluate uncertainty of paired monthly net-return differences with a time-block bootstrap. Stocks/months are not independent experimental replications.
- Report all planned cost scenarios and negative results. Subperiod comparisons are robustness diagnostics, not opportunities to retune on the test set.

## Responsibilities

1. Data snapshot, cleaning, feature engineering, target/split construction and data audit.
2. Time-ordered model training, validation, overfitting checks and prediction exports.
3. Shared portfolio accounting engine, baseline strategy, trading-cost scenarios and performance metrics.
4. Buffer implementation, validation selection, paired comparisons, uncertainty and interpretation.

## What Part 1 does not establish

No model has yet been fitted. No profitability, causal effect, transaction-cost advantage or grade is established by the data preparation. Data quality checks address the implemented transformations; they do not eliminate survivorship bias or prove a vendor's historical records are error-free.
