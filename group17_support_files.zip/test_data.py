"""Run with python test_data.py. Tests the saved real-data pipeline, not a model."""
from pathlib import Path
import numpy as np
import pandas as pd
from data_pipeline import clean_daily, daily_features, build_monthly, validate, FEATURES


def run_tests(root):
    raw = pd.read_csv(Path(root) / "daily_prices.csv.gz", parse_dates=["date"])
    d, removed, duplicates = clean_daily(raw)
    panel, excluded, f = build_monthly(d)
    checks = validate(panel, d)
    a = d.loc[d.ticker.eq("AAPL")].reset_index(drop=True)
    af = daily_features(a).reset_index(drop=True)
    j = 1000
    for h in [21, 63, 126, 252]:
        assert np.isclose(af.loc[j, f"ret_{h}d"], a.adj_close.iloc[j] / a.adj_close.iloc[j-h] - 1)
    assert np.isclose(af.loc[j, "momentum_252_21d"], a.adj_close.iloc[j-21] / a.adj_close.iloc[j-252] - 1)
    rd = a.adj_close.pct_change(fill_method=None)
    assert np.isclose(af.loc[j, "volatility_63d"], rd.iloc[j-62:j+1].std(ddof=1) * np.sqrt(252))
    checks["independent_feature_formulas"] = True
    assert af.loc[:251, "ret_252d"].isna().all()
    checks["no_lookback_backfill"] = True
    doubled = pd.concat([raw, raw.iloc[[0]]], ignore_index=True)
    c, _, n = clean_daily(doubled)
    assert len(c) == len(d) and n == 1
    checks["exact_duplicate_handling"] = True
    bad = raw.iloc[[0]].copy()
    bad["adj_close"] *= 2
    try:
        clean_daily(pd.concat([raw, bad], ignore_index=True))
    except ValueError:
        checks["conflicting_duplicates_rejected"] = True
    else:
        raise AssertionError("Conflicting duplicates accepted")
    bad = raw.copy()
    bad.loc[bad.index[0], "volume"] = 0
    c, rejected, _ = clean_daily(bad)
    assert len(rejected) == 1 and len(c) == len(d)-1
    checks["invalid_source_rows_logged"] = True
    for ticker, g in panel.groupby("ticker"):
        g = g.sort_values("signal_date")
        assert np.array_equal(g.exit_date.to_numpy()[:-1], g.entry_date.to_numpy()[1:])
    checks["consecutive_monthly_holding_intervals"] = True
    changed = a.copy()
    cut = pd.Timestamp("2018-12-31")
    changed.loc[changed.date.gt(cut), "adj_close"] *= 3.7
    mutated = daily_features(changed)
    assert np.allclose(af.loc[af.date.le(cut), FEATURES], mutated.loc[mutated.date.le(cut), FEATURES], equal_nan=True)
    checks["future_price_mutation_does_not_change_past_features"] = True
    assert panel.split.value_counts().to_dict() == {"train": 7150, "test": 3000, "validation": 2350, "purge": 100}
    checks["frozen_split_counts"] = True
    assert removed.empty and excluded.empty and duplicates == 0
    checks["snapshot_has_no_removed_records"] = True
    return checks


if __name__ == "__main__":
    import json
    root = Path(__file__).resolve().parent
    results = run_tests(root)
    (root / "processed" / "test_results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(f"{len(results)} / {len(results)} TESTS PASSED")
    for name in results:
        print("PASS:", name)
