"""Part 1: real daily prices -> leakage-aware monthly research panel.

No model fitting or portfolio strategy selection is performed here.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

import numpy as np
import pandas as pd

GROUPS = {
    "technology": "AAPL MSFT NVDA IBM ORCL INTC CSCO QCOM TXN ADBE",
    "consumer_and_retail": "AMZN WMT COST TGT HD LOW MCD NKE SBUX BKNG",
    "financials": "JPM BAC WFC GS MS AXP USB PNC SCHW BLK",
    "healthcare": "JNJ PFE MRK ABT AMGN GILD UNH CVS MDT BMY",
    "energy_and_industrials": "XOM CVX COP SLB CAT DE HON UPS UNP FDX",
}
TICKERS = [t for group in GROUPS.values() for t in group.split()]
FEATURES = [
    "ret_21d", "ret_63d", "ret_126d", "ret_252d", "momentum_252_21d",
    "volatility_21d", "volatility_63d", "volatility_126d", "downside_63d",
    "price_to_ma_21d", "price_to_ma_63d", "price_to_ma_252d",
    "drawdown_252d", "volume_ratio_21_126d", "volume_change_21d",
    "positive_days_63d",
]
START = "2003-01-01"
END_EXCLUSIVE = "2026-02-01"


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


def download_one(ticker: str, root: Path) -> dict:
    raw_dir = root / "raw_yahoo"
    raw_dir.mkdir(parents=True, exist_ok=True)
    path = raw_dir / f"{ticker}.json.gz"
    p1 = int(pd.Timestamp(START, tz="UTC").timestamp())
    p2 = int(pd.Timestamp(END_EXCLUSIVE, tz="UTC").timestamp())
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}"
           f"?period1={p1}&period2={p2}&interval=1d&events=div%2Csplits")
    cached = path.exists()
    if cached:
        payload = gzip.decompress(path.read_bytes())
    else:
        for attempt in range(3):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=35) as response:
                    payload = response.read()
                parsed = json.loads(payload)
                if parsed.get("chart", {}).get("error") or not parsed["chart"].get("result"):
                    raise ValueError(f"Yahoo returned no data for {ticker}")
                path.write_bytes(gzip.compress(payload, mtime=0))
                break
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403, 429):
                    raise RuntimeError(f"{ticker}: access/rate limit {exc.code}; use supplied snapshot") from exc
                if attempt == 2:
                    raise
                time.sleep(1 + attempt)
            except (TimeoutError, urllib.error.URLError):
                if attempt == 2:
                    raise
                time.sleep(1 + attempt)
    result = json.loads(payload)["chart"]["result"][0]
    if result["meta"].get("currency") != "USD":
        raise ValueError(f"Unexpected currency: {ticker}")
    q = result["indicators"]["quote"][0]
    a = result["indicators"].get("adjclose", [{}])[0].get("adjclose")
    if a is None:
        raise ValueError(f"Adjusted close missing: {ticker}")
    dates = (pd.to_datetime(result["timestamp"], unit="s", utc=True)
             .tz_convert("America/New_York").tz_localize(None).normalize())
    frame = pd.DataFrame({"ticker": ticker, "date": dates,
                          **{k: q[k] for k in ["open", "high", "low", "close", "volume"]},
                          "adj_close": a})
    frame = frame.loc[frame.date.ge(START) & frame.date.lt(END_EXCLUSIVE)].copy()
    return {"frame": frame, "manifest": {
        "ticker": ticker, "url": url, "cached": cached,
        "retrieved_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "payload_sha256": hashlib.sha256(payload).hexdigest(),
        "rows": len(frame), "first_date": frame.date.min(), "last_date": frame.date.max(),
    }}


def download(root: Path) -> pd.DataFrame:
    collected, manifest = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(download_one, t, root): t for t in TICKERS}
        failures = []
        for f in concurrent.futures.as_completed(futures):
            t = futures[f]
            try:
                value = f.result()
                collected.append(value["frame"])
                manifest.append(value["manifest"])
                print(f"Downloaded {t}: {len(value['frame'])} observations", flush=True)
            except Exception as exc:
                failures.append({"ticker": t, "error": str(exc)})
    write_json(root / "download_manifest.json", sorted(manifest, key=lambda x: x["ticker"]))
    if failures:
        write_json(root / "download_failures.json", failures)
        raise RuntimeError(f"Incomplete universe; not silently dropping stocks: {failures}")
    raw = pd.concat(collected, ignore_index=True).sort_values(["ticker", "date"])
    raw.to_csv(root / "daily_prices.csv.gz", index=False, compression={"method": "gzip", "mtime": 0})
    return raw


def clean_daily(raw: pd.DataFrame):
    d = raw.copy()
    d["date"] = pd.to_datetime(d["date"])
    keys = ["ticker", "date"]
    exact_duplicates = int(d.duplicated().sum())
    d = d.drop_duplicates()
    if d.duplicated(keys).any():
        raise ValueError("Conflicting duplicate ticker-date records")
    for c in ["open", "high", "low", "close", "adj_close", "volume"]:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    required = ["close", "adj_close", "volume"]
    invalid = d[required].isna().any(axis=1) | d["close"].le(0) | d["adj_close"].le(0) | d.volume.le(0)
    removed = d.loc[invalid].copy()
    d = d.loc[~invalid].sort_values(keys).reset_index(drop=True)
    if not np.isfinite(d[required].to_numpy()).all():
        raise ValueError("Non-finite source prices/volumes")
    return d, removed, exact_duplicates


def daily_features(d: pd.DataFrame) -> pd.DataFrame:
    """All windows end on the current day. No global scaling or backfilling."""
    out = []
    for ticker, g in d.groupby("ticker", sort=True):
        g = g.sort_values("date").copy()
        p, v = g.adj_close, g.volume
        r = p.pct_change(fill_method=None)
        for h in [21, 63, 126, 252]:
            g[f"ret_{h}d"] = p / p.shift(h) - 1
        g["momentum_252_21d"] = p.shift(21) / p.shift(252) - 1
        for h in [21, 63, 126]:
            g[f"volatility_{h}d"] = r.rolling(h, min_periods=h).std(ddof=1) * np.sqrt(252)
        g["downside_63d"] = np.sqrt(r.clip(upper=0).pow(2).rolling(63, min_periods=63).mean() * 252)
        for h in [21, 63, 252]:
            g[f"price_to_ma_{h}d"] = p / p.rolling(h, min_periods=h).mean() - 1
        g["drawdown_252d"] = p / p.rolling(252, min_periods=252).max() - 1
        av21 = v.rolling(21, min_periods=21).mean()
        g["volume_ratio_21_126d"] = av21 / v.rolling(126, min_periods=126).mean()
        g["volume_change_21d"] = av21 / av21.shift(21) - 1
        g["positive_days_63d"] = r.gt(0).where(r.notna()).rolling(63, min_periods=63).mean()
        g["daily_return"] = r
        out.append(g)
    return pd.concat(out, ignore_index=True)


def build_monthly(d: pd.DataFrame):
    f = daily_features(d)
    calendar = pd.DatetimeIndex(sorted(d.date.unique()))
    sessions = pd.DataFrame({"date": calendar})
    sessions["month"] = sessions.date.dt.to_period("M")
    schedule = sessions.groupby("month").date.agg(["first", "last"])
    parts = []
    for ticker, g in f.groupby("ticker", sort=True):
        g = g.set_index("date").sort_index()
        m = g.reindex(schedule["last"].to_numpy()).copy()
        m.index = schedule.index
        m["ticker"] = ticker
        m["signal_date"] = schedule["last"].to_numpy()
        m["holding_month"] = (m.index + 1).astype(str)
        m["entry_date"] = schedule["first"].shift(-1).to_numpy()
        m["exit_date"] = schedule["first"].shift(-2).to_numpy()
        m["entry_adj_close"] = m["entry_date"].map(g.adj_close)
        m["exit_adj_close"] = m["exit_date"].map(g.adj_close)
        m["target_return"] = m.exit_adj_close / m.entry_adj_close - 1
        m["source_month"] = m.index.astype(str)
        m = m.loc[m.holding_month.between("2005-01", "2025-12")].copy()
        m["split"] = np.select(
            [m.holding_month.le("2016-11"), m.holding_month.eq("2016-12"),
             m.holding_month.between("2017-01", "2020-11"), m.holding_month.eq("2020-12")],
            ["train", "purge", "validation", "purge"], default="test")
        m["features_complete"] = np.isfinite(m[FEATURES].to_numpy(dtype=float)).all(axis=1)
        m["target_available"] = np.isfinite(m.target_return)
        parts.append(m.reset_index(drop=True))
    full = pd.concat(parts, ignore_index=True).sort_values(["signal_date", "ticker"])
    columns = ["ticker", "signal_date", "holding_month", "entry_date", "exit_date", "split",
               *FEATURES, "target_return", "entry_adj_close", "exit_adj_close"]
    # Do not condition stock selection on future returns. Abort on unavailable labels instead.
    candidates = full.loc[full.features_complete].copy()
    if not candidates.target_available.all():
        raise ValueError("Missing future label in selected universe; inspect corporate events, do not silently drop")
    panel = candidates[columns].reset_index(drop=True)
    excluded = full.loc[~full.features_complete, ["ticker", "signal_date", "holding_month", "features_complete", "target_available"]]
    return panel, excluded, f


def validate(panel: pd.DataFrame, clean: pd.DataFrame):
    checks = {}
    checks["unique_stock_month"] = not panel.duplicated(["ticker", "signal_date"]).any()
    checks["all_features_finite"] = bool(np.isfinite(panel[FEATURES].to_numpy()).all())
    checks["all_targets_finite"] = bool(np.isfinite(panel.target_return).all())
    checks["strict_trade_timing"] = bool(((panel.signal_date < panel.entry_date) & (panel.entry_date < panel.exit_date)).all())
    checks["target_arithmetic"] = bool(np.allclose(panel.target_return, panel.exit_adj_close / panel.entry_adj_close - 1, atol=1e-12))
    checks["return_above_minus_one"] = bool(panel.target_return.gt(-1).all())
    tr = panel.loc[panel.split.eq("train")]
    va = panel.loc[panel.split.eq("validation")]
    te = panel.loc[panel.split.eq("test")]
    checks["train_labels_known_before_validation"] = bool(tr.exit_date.max() <= va.signal_date.min())
    checks["validation_labels_known_before_test"] = bool(va.exit_date.max() <= te.signal_date.min())
    checks["50_stocks_each_month"] = bool(panel.groupby("signal_date").ticker.nunique().eq(50).all())
    checks["expected_252_holding_months"] = panel.holding_month.nunique() == 252
    # Independent raw-price lookup for three labels, including split boundaries.
    lookup = clean.set_index(["ticker", "date"]).adj_close
    checks["independent_target_spot_check"] = all(
        np.isclose(row.target_return, lookup.loc[(row.ticker, row.exit_date)] / lookup.loc[(row.ticker, row.entry_date)] - 1)
        for row in panel.iloc[[0, len(panel)//2, -1]].itertuples())
    # Prefix invariance: deleting the future must not alter any historical feature.
    cut = pd.Timestamp("2018-12-31")
    small = clean.loc[clean.ticker.isin(["AAPL", "JPM"])]
    all_f = daily_features(small).set_index(["ticker", "date"])[FEATURES]
    prefix = daily_features(small.loc[small.date.le(cut)]).set_index(["ticker", "date"])[FEATURES]
    checks["prefix_invariance_no_feature_lookahead"] = bool(np.allclose(all_f.loc[prefix.index], prefix, equal_nan=True))
    # One-month labels must never be re-shifted by the modelling participant.
    checks["feature_list_excludes_targets_and_execution_prices"] = not set(FEATURES) & {"target_return", "entry_adj_close", "exit_adj_close"}
    if not all(checks.values()):
        raise AssertionError(checks)
    return checks


def run(root: Path):
    root = Path(root)
    source = root / "daily_prices.csv.gz"
    if not source.exists():
        raise FileNotFoundError("Load the provided data snapshot first, or run with --download")
    raw = pd.read_csv(source, parse_dates=["date"])
    clean, removed, duplicates = clean_daily(raw)
    panel, excluded, daily = build_monthly(clean)
    checks = validate(panel, clean)
    out = root / "processed"
    out.mkdir(exist_ok=True)
    panel.to_csv(out / "panel_monthly.csv", index=False, float_format="%.12g")
    for split in ["train", "validation", "test", "purge"]:
        panel.loc[panel.split.eq(split)].to_csv(out / f"{split}.csv", index=False, float_format="%.12g")
    write_json(out / "feature_columns.json", FEATURES)
    removed.to_csv(out / "removed_daily_rows.csv", index=False)
    excluded.to_csv(out / "excluded_monthly_rows.csv", index=False)
    coverage = clean.groupby("ticker").agg(first_date=("date", "min"), last_date=("date", "max"), daily_rows=("date", "size"))
    coverage["selection_group"] = [next(k for k,v in GROUPS.items() if t in v.split()) for t in coverage.index]
    coverage["monthly_rows"] = panel.groupby("ticker").size()
    coverage["missing_sessions_vs_union"] = clean.date.nunique() - coverage.daily_rows
    coverage.to_csv(out / "coverage.csv")
    # Record gaps explicitly; do not fabricate weekend/holiday observations.
    missing_pairs = pd.MultiIndex.from_product([TICKERS, sorted(clean.date.unique())], names=["ticker", "date"]).difference(pd.MultiIndex.from_frame(clean[["ticker", "date"]]))
    missing_pairs.to_frame(index=False).to_csv(out / "missing_sessions.csv", index=False)
    extremes = daily.loc[daily.daily_return.abs().gt(.25), ["ticker", "date", "daily_return", "adj_close", "close"]]
    extremes.to_csv(out / "extreme_daily_moves.csv", index=False)
    panel.groupby("split").agg(rows=("ticker", "size"), stocks=("ticker", "nunique"),
                                first_holding_month=("holding_month", "min"), last_holding_month=("holding_month", "max"),
                                first_signal=("signal_date", "min"), last_exit=("exit_date", "max")).to_csv(out / "split_summary.csv")
    panel[FEATURES].isna().sum().rename("missing_count").to_csv(out / "feature_missingness.csv")
    panel.loc[panel.split.eq("train"), FEATURES].describe().T.to_csv(out / "feature_summary_train_only.csv")
    report = {"raw_rows": len(raw), "clean_rows": len(clean), "exact_duplicates_removed": duplicates,
              "invalid_daily_rows_removed": len(removed), "monthly_rows": len(panel), "stocks": panel.ticker.nunique(),
              "months": panel.holding_month.nunique(), "excluded_monthly_rows": len(excluded),
              "missing_stock_sessions": len(missing_pairs), "extreme_daily_moves_flagged_not_deleted": len(extremes),
              "features": len(FEATURES), "split_counts": panel.split.value_counts().to_dict(),
              "checks": checks, "snapshot_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
              "limits": ["Fixed ex-post selection of surviving stocks", "Not the original paper's CRSP/Compustat universe",
                         "No credit ratings, microcap universe, historical constituents or delisting returns",
                         "Adjusted-price history is a current vendor snapshot, not point-in-time vintage data",
                         "No trained models, strategy returns or claimed performance improvement in Part 1"]}
    write_json(out / "quality_report.json", report)
    return panel, report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    args.root.mkdir(parents=True, exist_ok=True)
    if args.download:
        download(args.root)
    panel, report = run(args.root)
    print(json.dumps(report, indent=2, default=str))
