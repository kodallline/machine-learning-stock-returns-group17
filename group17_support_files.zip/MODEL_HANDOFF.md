# Handoff to modelling and portfolio participants

## Data contract

Read `feature_columns.json` and use exactly those 16 numeric columns as X. The target is `target_return`, a decimal gross total-return proxy for the next monthly holding interval. A value of 0.02 means 2%, not 0.02%.

The primary key is `(ticker, signal_date)`. Keep `holding_month`, `entry_date`, `exit_date` and `split` for alignment, not as numerical predictors. Never use `entry_adj_close`, `exit_adj_close` or `target_return` in X. No extra shift of X or y is needed. Tickers and selection groups are not included as predictors in the baseline.

## Frozen initial split

| Set | Holding months | Purpose |
|---|---|---|
| Train | 2005-01 to 2016-11 | Estimate initial model and preprocessing |
| Purge | 2016-12 | Prevent a label extending beyond the first validation signal |
| Validation | 2017-01 to 2020-11 | Select hyperparameters and holding buffer |
| Purge | 2020-12 | Prevent a label extending beyond the first test signal |
| Test | 2021-01 to 2025-12 | One final out-of-sample evaluation |

Example: the December 2020 holding return is observed only at the first trading close in January 2021, after the signal for the January test trade. It cannot be used to select the model before that signal. Thus the two boundary holding months are explicitly purged, not accidentally lost.

## Model protocol

1. Use pooled stock-month Ridge as the benchmark and an NN3 network (suggested hidden widths 32/16/8) as the nonlinear alternative. The 16-feature architecture is an adaptation, not the original 920-input GKX specification.
2. Keep all stocks from a signal month in the same time fold. Do not use random train/test splitting.
3. Fit imputation, clipping thresholds (if introduced) and scaling only on the current training data. Part 1 has deliberately not fitted a global scaler or imputer.
4. Use time-ordered internal folds or an internal tail of the training sample for early stopping during validation experiments. Do not use test labels for early stopping.
5. A simple first experiment fits on `train.csv`, selects model/buffer choices on `validation.csv`, then refits with all historical labels satisfying `exit_date <= first_test_signal_date`. Fix the stopping budget using pre-test data.
6. If annual expanding refits are used, at each annual signal cutoff train only on rows whose `exit_date <= cutoff`. Refit preprocessing too. Hyperparameters and buffer remain frozen after validation. Earlier test outcomes may become training data later only under this predeclared sequential refitting rule.
7. Once test predictions are produced, do not change features, sample, model or buffer in response to test performance and call the result untouched out-of-sample.
8. Include seeds and run logs. With this small panel, a neural network may fail to beat Ridge. Report that result rather than hiding it.

## Required prediction export

`ticker, signal_date, holding_month, entry_date, exit_date, model, predicted_return, target_return`

For every model and evaluated month there must be exactly 50 unique stock predictions. No duplications, missing predictions or future-filled values. Save validation predictions for buffer selection as well as test predictions.

## Portfolio alignment

- All trades occur at `entry_date`, never at `signal_date`.
- Each target spans `entry_date` to `exit_date`. These holding intervals are consecutive across months.
- Buy/sell rules use only contemporaneously available predictions and previous holdings. Never use the target to rank/select positions.
- Baseline top 10% corresponds to 5 stocks. A 20% retention threshold corresponds to rank 10. Specify deterministic ticker-based tie breaking.
- The buffer implementation must specify how it handles incumbent positions and vacant slots. Keeping a fixed 5-position portfolio avoids confounding the buffer with a variable stock count. A possible rule: retain incumbents ranked <=10, fill remaining slots with the best-ranked nonheld stocks until there are 5 positions. This relaxes the top-5 entry rule when incumbents occupy high ranks; document the exact rule and use it consistently.
- Under equal-weighting, retained stocks may still require trades as weights drift. Charge those rebalancing trades too; a retained ticker is not automatically zero turnover.
- Charge scenario cost `c * sum(abs(w_new - w_pretrade))`, with `c` a one-way cost per dollar traded. Do not use half-turnover in the cost formula unless the cost convention is changed consistently. Specify initial purchases and final liquidation costs.
- Benchmark: equal-weighted portfolio of the same 50 stocks using the same execution schedule. It is not the market portfolio or historical S&P 500.
- For a Sharpe ratio, either obtain aligned risk-free returns or explicitly report the zero-risk-free approximation. It is not FF6 alpha.

## Limits already known

Fixed, ex-post survivor universe; no delisted stocks; no point-in-time constituent history; only 50 stocks; 16 technical predictors, not 920 original inputs; no ratings or NYSE market-cap breakpoints; approximate adjusted-price return accounting; no observed spread/market-impact/borrow data; scenario transaction costs; only 60 test holding months. The strategy is long-only. This does not reproduce the paper's long-short results.
